create database loja;

use loja;

create table vendedor (
    codigo integer not null auto_increment,
    nome varchar(50) not null,
    salario float not null check (salario > 0),
    primary key (codigo)
);

insert into vendedor (nome,salario) values ('Mauricio Costa Quaresma',500.00);
insert into vendedor (nome,salario) values ('Paulo Lopes Nunes',500.00);
insert into vendedor (nome,salario) values ('Patricia Menezes Silva',500.00);
insert into vendedor (nome,salario) values ('Cristiano Lopes Bezerra',550.00);
insert into vendedor (nome,salario) values ('Michele Menezes Santos',550.00);
insert into vendedor (nome,salario) values ('Cristiane Nunes Brandao',500.00);
insert into vendedor (nome,salario) values ('Pedro Rosa Loureiro',850.00);
insert into vendedor (nome,salario) values ('Jose Souza Martins',550.00);
insert into vendedor (nome,salario) values ('Gabriel Albuquerque Menezes',500.00);
insert into vendedor (nome,salario) values ('Mauricio Bezerra Lopes',550.00);
