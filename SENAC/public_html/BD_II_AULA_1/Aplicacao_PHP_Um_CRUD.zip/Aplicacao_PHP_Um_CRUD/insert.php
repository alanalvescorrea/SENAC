<html>
<body>
<?php
$erro = "";
if (isset($_POST["confirma"]))
{   if (trim($_POST["nome"]) == "")
    {   $erro = "Nome inv&aacute;lido!";
    }
    else
    {   if (!is_numeric($_POST["salario"]))
        {   $erro = "Sal&aacute;rio inv&aacute;lido!";
        }
        else
        {   if (($_POST["salario"]+0) < 0)
            {   $erro = "Sal&aacute;rio inv&aacute;lido!";
            }
            else
            {   $conexao = mysql_connect("localhost","root","");
                mysql_select_db("loja");
                mysql_query("insert into vendedor (nome,salario) values ('".$_POST["nome"]."',".$_POST["salario"].")");
                echo mysql_affected_rows($conexao)." registro(s) inclu&iacute;dos(s)";
                mysql_close($conexao);
            }
        }
    }
}
if ((!isset($_POST["confirma"])) || ($erro != ""))
{   if ($erro != "")
    {   echo "<b><font color=red>".$erro."</font></b><br>";
    }
    echo "<form name=insert action=insert.php method=post>";
    echo "<table border=2>";
    echo "<tr>";
    echo "<td>Nome</td>";
    echo "<td><input type=text name=nome value=\"".(isset($_POST["nome"])?$_POST["nome"]:"")."\" size=50></td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td>Sal&aacute;rio</td>";
    echo "<td><input type=text name=salario value=\"".(isset($_POST["salario"])?$_POST["salario"]:"")."\" size=10></td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td colspan=2 align=center><input type=submit name=confirma value=Confirma size=10></td>";
    echo "</tr>";
    echo "</table>";
    echo "</form>";
}
?>
</body>
</html>
