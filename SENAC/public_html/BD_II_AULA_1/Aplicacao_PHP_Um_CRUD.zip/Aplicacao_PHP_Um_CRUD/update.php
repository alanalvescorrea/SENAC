<html>
<body>
<?php
$mostra = true;
$erro = "";
if (isset($_GET["codigo"]))
{   $conexao = mysql_connect("localhost","root","");
    mysql_select_db("loja");
    $resultado = mysql_query("select * from vendedor where codigo = ".$_GET["codigo"]);
    if (mysql_num_rows($resultado) > 0)
    {   $registro = mysql_fetch_array($resultado);
        $codigo = $registro["codigo"];
        $nome = $registro["nome"];
        $salario = $registro["salario"];
    }
    else
    {   $mostra = false;
        $erro = "C&oacute;digo inv&aacute;lido!";
    }
    mysql_close($conexao);
}
else
{   if (isset($_POST["confirma"]))
    {   $codigo = $_POST["codigo"];
        $nome = $_POST["nome"];
        $salario = $_POST["salario"];
        if (trim($_POST["nome"]) == "")
        {   $erro = "Nome inv&aacute;lido!";
        }
        else
        {   if (!is_numeric($_POST["salario"]))
            {   $erro = "Sal&aacute;rio inv&aacute;lido!";
            }
            else
            {   if (($_POST["salario"]+0) < 0)
                {   $erro = "Sal&aacute;rio inv&aacute;lido!";
                }
                else
                {   $conexao = mysql_connect("localhost","root","");
                    mysql_select_db("loja");
                    mysql_query("update vendedor set nome = '".$_POST["nome"]."', salario = ".$_POST["salario"]." where codigo = ".$_POST["codigo"]);
                    echo mysql_affected_rows($conexao)." registro(s) alterado(s)";
                    mysql_close($conexao);
                    $mostra = false;
                }
            }
        }
    }
    else
    {   $mostra = false;
        $erro = "Par&acirc;metros incorretos!";
    }
}
if ($erro != "")
{   echo "<b><font color=red>".$erro."</font></b><br>";
}
if ($mostra)
{   echo "<form name=update action=update.php method=post>";
    echo "<input type=hidden name=codigo value=".$codigo.">";
    echo "<table border=2>";
    echo "<tr>";
    echo "<td>Nome</td>";
    echo "<td><input type=text name=nome value=\"".$nome."\" size=50></td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td>Sal&aacute;rio</td>";
    echo "<td><input type=text name=salario value=\"".$salario."\" size=10></td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td colspan=2 align=center><input type=submit name=confirma value=Confirma size=10></td>";
    echo "</tr>";
    echo "</table>";
    echo "</form>";
}
?>
</body>
</html>
