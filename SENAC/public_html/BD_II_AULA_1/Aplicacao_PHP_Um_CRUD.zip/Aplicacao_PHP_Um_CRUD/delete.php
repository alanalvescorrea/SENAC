<html>
<body>
<?php
if (isset($_GET["codigo"]))
{   $conexao = mysql_connect("localhost","root","");
    mysql_select_db("loja");
    mysql_query("delete from vendedor where codigo = ".$_GET["codigo"]);
    echo mysql_affected_rows($conexao)." registro(s) exclu&iacute;do(s)";
    mysql_close($conexao);
}
else
{   echo "<b><font color=red>Par&acirc;metros incorretos!</font></b>";
}
?>
</body>
</html>
