<html>
<body>
<table border=2>
<tr><td>C&oacute;digo</td><td>Nome</td><td>Sal&aacute;rio</td></tr>
<?php
$where = (isset($_GET["nome"]))?"where nome like '%".str_replace(" ","%",$_GET["nome"])."%'":"";
$orderby = (isset($_GET["orderby"]))?"order by ".$_GET["orderby"]:"";
$limit = (isset($_GET["limit"]))?"limit ".$_GET["limit"]:"";
$offset = (isset($_GET["offset"]))?"offset ".$_GET["offset"]:"";
$conexao = mysql_connect("localhost","root","");
mysql_select_db("loja");
$resultado = mysql_query("select * from vendedor ".$where." ".$orderby." ".$limit." ".$offset);
for ($linha = 0; $linha < mysql_num_rows($resultado); $linha++)
{   $registro = mysql_fetch_array($resultado);
    echo "<tr><td>".$registro["codigo"]."</td><td>".$registro["nome"]."</td><td>".$registro["salario"]."</td></tr>";
}
mysql_close($conexao);
?>
</table>
<br>
<b><u>Exemplos de uso:</u></b><br>
<br>
http://127.0.0.1/select.php<br>
http://127.0.0.1/select.php?limit=5<br>
http://127.0.0.1/select.php?limit=5&offset=0<br>
http://127.0.0.1/select.php?limit=5&offset=5<br>
http://127.0.0.1/select.php?orderby=salario+asc<br>
http://127.0.0.1/select.php?orderby=salario+desc<br>
http://127.0.0.1/select.php?orderby=salario+desc&limit=5&offset=0<br>
http://127.0.0.1/select.php?nome=lopes<br>
http://127.0.0.1/select.php?nome=cris+lopes<br>
http://127.0.0.1/select.php?nome=lopes&orderby=salario+desc<br>
<br>
http://127.0.0.1/insert.php<br>
<br>
http://127.0.0.1/update.php?codigo=1<br>
<br>
http://127.0.0.1/delete.php?codigo=1<br>
</body>
</html>
